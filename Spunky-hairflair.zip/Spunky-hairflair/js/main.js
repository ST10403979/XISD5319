// ========================================
// Spunky's Hairflair - FULLY FUNCTIONAL
// Login, Booking, Persistence - ALL WORK
// ========================================

// Global variables
let currentUser = null;
let userBookings = [];

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    loadDataFromStorage();
    checkLoginStatus();
    initNavigation();
    initBookingPage();
    displayAllServices();
});

// ============ DATA STORAGE ============
function loadDataFromStorage() {
    const savedUser = localStorage.getItem('spunky_currentUser');
    const savedBookings = localStorage.getItem('spunky_userBookings');
    
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
    }
    
    if (savedBookings) {
        userBookings = JSON.parse(savedBookings);
    }
}

function saveUserData() {
    if (currentUser) {
        localStorage.setItem('spunky_currentUser', JSON.stringify(currentUser));
    }
    localStorage.setItem('spunky_userBookings', JSON.stringify(userBookings));
}

// ============ LOGIN SYSTEM ============
function checkLoginStatus() {
    const homePage = document.getElementById('homePage');
    const bookingsPage = document.getElementById('bookingsPage');
    const servicesPage = document.getElementById('servicesPage');
    const contactPage = document.getElementById('contactPage');
    const loginRequired = document.getElementById('loginRequiredMessage');
    const userIcon = document.getElementById('userIcon');
    
    if (currentUser) {
        // User is logged in - show all content
        loginRequired.style.display = 'none';
        
        // Show the appropriate page based on active nav
        const activePage = document.querySelector('.nav-links a.active').dataset.page;
        if (activePage === 'home') {
            homePage.style.display = 'block';
            bookingsPage.style.display = 'none';
            servicesPage.style.display = 'none';
            contactPage.style.display = 'none';
        } else if (activePage === 'bookings') {
            homePage.style.display = 'none';
            bookingsPage.style.display = 'block';
            servicesPage.style.display = 'none';
            contactPage.style.display = 'none';
            displayUserBookings();
        } else if (activePage === 'services') {
            homePage.style.display = 'none';
            bookingsPage.style.display = 'none';
            servicesPage.style.display = 'block';
            contactPage.style.display = 'none';
        } else if (activePage === 'contact') {
            homePage.style.display = 'none';
            bookingsPage.style.display = 'none';
            servicesPage.style.display = 'none';
            contactPage.style.display = 'block';
        }
        
        // Update user icon and greeting
        userIcon.innerHTML = '👤';
        const userNameDisplay = document.getElementById('userNameDisplay');
        if (userNameDisplay) {
            userNameDisplay.textContent = currentUser.name.split(' ')[0];
        }
        
        // Update all user greetings
        document.querySelectorAll('.user-greeting span').forEach(el => {
            if (el.innerHTML.includes('Welcome') || el.innerHTML.includes('My Appointment')) {
                // Don't change the text content structure
            }
        });
        
    } else {
        // User not logged in - show login prompt
        loginRequired.style.display = 'block';
        homePage.style.display = 'none';
        bookingsPage.style.display = 'none';
        servicesPage.style.display = 'none';
        contactPage.style.display = 'none';
        userIcon.innerHTML = '🔐';
    }
}

function login() {
    const name = document.getElementById('loginName').value.trim();
    const email = document.getElementById('loginEmail').value.trim();
    const phone = document.getElementById('loginPhone').value.trim();
    
    if (!name || !email || !phone) {
        alert('Please fill in all fields to continue');
        return;
    }
    
    currentUser = {
        id: Date.now(),
        name: name,
        email: email,
        phone: phone,
        joinedDate: new Date().toISOString()
    };
    
    saveUserData();
    closeModal();
    checkLoginStatus();
    
    // Reset booking selections for new user
    resetCurrentBooking();
    
    alert(`Welcome ${name.split(' ')[0]}! You can now book appointments.`);
}

function logout() {
    currentUser = null;
    saveUserData();
    resetCurrentBooking();
    checkLoginStatus();
    
    // Reset navigation to home
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === 'home') {
            link.classList.add('active');
        }
    });
    
    alert('You have been logged out.');
}

function openAuthModal() {
    if (currentUser) {
        // If logged in, show user info instead
        alert(`Logged in as: ${currentUser.name}\nEmail: ${currentUser.email}\nPhone: ${currentUser.phone}`);
    } else {
        document.getElementById('authModal').classList.add('active');
        // Clear form
        document.getElementById('loginName').value = '';
        document.getElementById('loginEmail').value = '';
        document.getElementById('loginPhone').value = '';
    }
}

function closeModal() {
    document.getElementById('authModal').classList.remove('active');
}

// ============ NAVIGATION ============
function initNavigation() {
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.dataset.page;
            
            // Update active class
            document.querySelectorAll('.nav-links a').forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            
            if (!currentUser && page !== 'services' && page !== 'contact') {
                // Show login required
                checkLoginStatus();
                return;
            }
            
            // Hide all pages
            document.getElementById('homePage').style.display = 'none';
            document.getElementById('bookingsPage').style.display = 'none';
            document.getElementById('servicesPage').style.display = 'none';
            document.getElementById('contactPage').style.display = 'none';
            document.getElementById('loginRequiredMessage').style.display = 'none';
            
            // Show selected page
            if (page === 'home') {
                document.getElementById('homePage').style.display = 'block';
                updateSummaryDisplay(); // Refresh summary
            } else if (page === 'bookings') {
                document.getElementById('bookingsPage').style.display = 'block';
                displayUserBookings();
            } else if (page === 'services') {
                document.getElementById('servicesPage').style.display = 'block';
            } else if (page === 'contact') {
                document.getElementById('contactPage').style.display = 'block';
            }
        });
    });
}

// ============ BOOKING SYSTEM ============
let currentBooking = {
    service: null,
    price: 0,
    stylistId: null,
    stylistName: null,
    date: null,
    time: null
};

function resetCurrentBooking() {
    currentBooking = {
        service: null,
        price: 0,
        stylistId: null,
        stylistName: null,
        date: null,
        time: null
    };
    updateSummaryDisplay();
    
    // Remove visual selections
    document.querySelectorAll('.service-card, .stylist-option, .date-day, .time-slot').forEach(el => {
        el.classList.remove('selected');
    });
}

function initBookingPage() {
    initServiceSelection();
    initStylistSelection();
    initDatePicker();
    initTimeSlots();
    
    const confirmBtn = document.getElementById('continueBtn');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', confirmBooking);
    }
}

function initServiceSelection() {
    document.querySelectorAll('.service-card').forEach(card => {
        card.addEventListener('click', () => {
            if (!currentUser) {
                alert('Please login first to book an appointment');
                openAuthModal();
                return;
            }
            document.querySelectorAll('.service-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            currentBooking.service = card.dataset.service;
            currentBooking.price = parseInt(card.dataset.price);
            updateSummaryDisplay();
        });
    });
}

function initStylistSelection() {
    document.querySelectorAll('.stylist-option').forEach(option => {
        option.addEventListener('click', () => {
            if (!currentUser) {
                alert('Please login first to book an appointment');
                openAuthModal();
                return;
            }
            document.querySelectorAll('.stylist-option').forEach(o => o.classList.remove('selected'));
            option.classList.add('selected');
            currentBooking.stylistId = option.dataset.stylistId;
            currentBooking.stylistName = option.dataset.stylistName;
            updateSummaryDisplay();
        });
    });
}

function initDatePicker() {
    const datePicker = document.getElementById('datePicker');
    if (!datePicker) return;
    
    const today = new Date();
    const dates = [];
    
    for (let i = 0; i < 14; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        dates.push(date);
    }
    
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    datePicker.innerHTML = dates.map((date, index) => {
        const dayNum = date.getDate();
        const weekday = weekdays[date.getDay()];
        
        return `
            <div class="date-day" data-date="${date.toISOString().split('T')[0]}">
                <div class="date-day-weekday">${weekday}</div>
                <div class="date-day-number">${dayNum}</div>
            </div>
        `;
    }).join('');
    
    document.querySelectorAll('.date-day').forEach(day => {
        day.addEventListener('click', () => {
            if (!currentUser) {
                alert('Please login first to book an appointment');
                openAuthModal();
                return;
            }
            document.querySelectorAll('.date-day').forEach(d => d.classList.remove('selected'));
            day.classList.add('selected');
            currentBooking.date = day.dataset.date;
            updateSummaryDisplay();
        });
    });
}

function initTimeSlots() {
    const timeSlots = document.getElementById('timeSlots');
    if (!timeSlots) return;
    
    const times = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'];
    
    timeSlots.innerHTML = times.map(time => {
        return `<div class="time-slot" data-time="${time}">⏰ ${time}</div>`;
    }).join('');
    
    document.querySelectorAll('.time-slot').forEach(slot => {
        slot.addEventListener('click', () => {
            if (!currentUser) {
                alert('Please login first to book an appointment');
                openAuthModal();
                return;
            }
            document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
            slot.classList.add('selected');
            currentBooking.time = slot.dataset.time;
            updateSummaryDisplay();
        });
    });
}

function updateSummaryDisplay() {
    const summaryCard = document.getElementById('summaryCard');
    const summaryBox = document.getElementById('summaryBox');
    
    if (!summaryBox) return;
    
    if (currentBooking.service && currentBooking.stylistName && currentBooking.date && currentBooking.time) {
        summaryCard.style.display = 'block';
        const deposit = currentBooking.price * 0.5;
        const balance = currentBooking.price - deposit;
        
        summaryBox.innerHTML = `
            <div class="summary-row"><span>✨ Service:</span><strong>${currentBooking.service}</strong></div>
            <div class="summary-row"><span>💇 Stylist:</span><strong>${currentBooking.stylistName}</strong></div>
            <div class="summary-row"><span>📅 Date:</span><strong>${formatDate(currentBooking.date)}</strong></div>
            <div class="summary-row"><span>⏰ Time:</span><strong>${currentBooking.time}</strong></div>
            <div class="summary-row" style="border-top: 2px solid #e0e0e0; margin-top: 0.5rem; padding-top: 0.5rem;">
                <span>💰 Total Amount:</span><strong style="color: var(--primary);">R${currentBooking.price}</strong>
            </div>
            <div class="summary-row"><span>💳 50% Deposit Due:</span><strong>R${deposit}</strong></div>
            <div class="summary-row"><span>💵 Balance at salon:</span><strong>R${balance}</strong></div>
        `;
    } else {
        summaryCard.style.display = 'none';
    }
}

function confirmBooking() {
    if (!currentUser) {
        alert('Please login first to book an appointment');
        openAuthModal();
        return;
    }
    
    if (!currentBooking.service || !currentBooking.stylistName || !currentBooking.date || !currentBooking.time) {
        alert('Please complete all selections: Service, Stylist, Date, and Time');
        return;
    }
    
    // Check for duplicate booking
    const isDuplicate = userBookings.some(booking => 
        booking.date === currentBooking.date && 
        booking.time === currentBooking.time &&
        booking.status !== 'cancelled'
    );
    
    if (isDuplicate) {
        alert('This time slot is already booked. Please select another time.');
        return;
    }
    
    // Create new booking
    const newBooking = {
        id: Date.now(),
        userId: currentUser.id,
        service: currentBooking.service,
        price: currentBooking.price,
        stylistId: currentBooking.stylistId,
        stylistName: currentBooking.stylistName,
        date: currentBooking.date,
        time: currentBooking.time,
        deposit: currentBooking.price * 0.5,
        status: 'confirmed',
        bookedOn: new Date().toISOString()
    };
    
    userBookings.push(newBooking);
    saveUserData();
    
    // Show success message
    const successDiv = document.getElementById('bookingSuccessMessage');
    successDiv.style.display = 'block';
    successDiv.innerHTML = `
        <div class="booking-success">
            ✅ <strong>Booking Confirmed!</strong><br>
            Your appointment with ${newBooking.stylistName} on ${formatDate(newBooking.date)} at ${newBooking.time} has been booked.<br>
            Deposit of R${newBooking.deposit} is required to secure your slot.
        </div>
    `;
    
    // Reset current booking
    resetCurrentBooking();
    
    // Remove visual selections from UI
    document.querySelectorAll('.service-card, .stylist-option, .date-day, .time-slot').forEach(el => {
        el.classList.remove('selected');
    });
    
    // Hide success message after 5 seconds
    setTimeout(() => {
        successDiv.style.display = 'none';
    }, 5000);
    
    // Refresh bookings display
    displayUserBookings();
}

// ============ DISPLAY FUNCTIONS ============
function formatDate(dateString) {
    if (!dateString) return 'Not selected';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-ZA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function displayUserBookings() {
    const container = document.getElementById('bookingsList');
    if (!container) return;
    
    const userSpecificBookings = userBookings.filter(b => b.userId === currentUser?.id);
    
    if (userSpecificBookings.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 3rem;">
                <p style="font-size: 3rem; margin-bottom: 1rem;">📅</p>
                <p>You have no bookings yet.</p>
                <button class="btn btn-primary" style="margin-top: 1rem;" onclick="document.querySelector('[data-page=\'home\']').click()">
                    Book Your First Appointment
                </button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <table class="bookings-table">
            <thead>
                <tr><th>Service</th><th>Stylist</th><th>Date</th><th>Time</th><th>Deposit</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
                ${userSpecificBookings.map((booking, index) => `
                    <tr>
                        <td><strong>${booking.service}</strong></td>
                        <td>${booking.stylistName}</td>
                        <td>${formatDate(booking.date)}</td>
                        <td>${booking.time}</td>
                        <td>R${booking.deposit}</td>
                        <td><span class="status-badge status-confirmed">CONFIRMED</span></td>
                        <td><button class="btn-outline" style="padding: 0.25rem 0.75rem;" onclick="cancelBooking(${booking.id})">Cancel</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
        userBookings = userBookings.filter(b => b.id !== bookingId);
        saveUserData();
        displayUserBookings();
        alert('Your appointment has been cancelled.');
    }
}

function displayAllServices() {
    const services = [
        { name: 'Wash & Blow', price: 150, duration: '45 min', icon: '💇‍♀️', description: 'Luxury wash followed by professional blow-dry styling.' },
        { name: 'Trim & Style', price: 120, duration: '30 min', icon: '✂️', description: 'Precision trim and style to refresh your look.' },
        { name: 'Box Braids', price: 450, duration: '3-4 hours', icon: '🧶', description: 'Classic medium box braids with your choice of length.' },
        { name: 'Sew-in Weave', price: 350, duration: '2-3 hours', icon: '💈', description: 'Professional weave installation with natural blend.' },
        { name: 'Relaxer Treatment', price: 250, duration: '1.5 hours', icon: '🧴', description: 'Safe and effective relaxing treatment.' },
        { name: 'Full Style & Blowout', price: 200, duration: '1 hour', icon: '💨', description: 'Complete styling with luxury blowout.' }
    ];
    
    const container = document.getElementById('servicesList');
    if (container) {
        container.innerHTML = services.map(service => `
            <div class="service-card" style="flex-direction: column; text-align: center; cursor: default;">
                <div class="service-name" style="font-size: 2.5rem;">${service.icon}</div>
                <div style="font-weight: 700; margin-top: 0.5rem; font-size: 1.1rem;">${service.name}</div>
                <div style="color: var(--gray); font-size: 0.8rem; margin: 0.25rem 0;">${service.duration}</div>
                <div style="font-size: 0.875rem; margin: 0.5rem 0;">${service.description}</div>
                <div class="service-price" style="margin-top: 0.5rem;">R${service.price}</div>
            </div>
        `).join('');
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('authModal');
    if (event.target === modal) {
        closeModal();
    }
}